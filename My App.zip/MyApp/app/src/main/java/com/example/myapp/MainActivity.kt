package com.example.myapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    private val dbUrl = "https://aquaalertiot-default-rtdb.firebaseio.com"
    private var buzzerSilenciado = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvEstado = findViewById<TextView>(R.id.tvEstado)
        val tvDistancia = findViewById<TextView>(R.id.tvDistancia)
        val switchSistema = findViewById<SwitchMaterial>(R.id.switchSistema)
        val btnSilenciar = findViewById<Button>(R.id.btnSilenciar)

        val dbRef = FirebaseDatabase.getInstance(dbUrl).getReference("dispositivo_01")

        // 1. Escuchar cambios en tiempo real de forma segura
        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) return

                val distancia = snapshot.child("distancia_cm").value?.toString()?.toDoubleOrNull() ?: 0.0
                val alertaActiva = leerBooleano(snapshot.child("alerta_activa").value, false)
                val encendido = leerBooleano(snapshot.child("sistema_encendido").value, true)
                buzzerSilenciado = leerBooleano(snapshot.child("silenciar_buzzer").value, false)

                tvDistancia.text = getString(R.string.distancia_format, distancia.toString())
                tvEstado.text = if (alertaActiva) {
                    getString(R.string.alerta_agua_bloqueando)
                } else {
                    getString(R.string.estado_normal)
                }

                btnSilenciar.text = if (buzzerSilenciado) "Reactivar Buzzer" else "Silenciar Buzzer"

                if (switchSistema.isChecked != encendido) {
                    switchSistema.isChecked = encendido
                }
            }

            override fun onCancelled(error: DatabaseError) {
                tvEstado.text = "Error lectura: ${error.message}"
            }
        })

        // 2. Enviar estado del switch a Firebase
        switchSistema.setOnCheckedChangeListener { _, isChecked ->
            dbRef.child("sistema_encendido").setValue(isChecked)
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error al guardar: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }

        // 3. Alternar silenciar/reactivar buzzer en Firebase
        btnSilenciar.setOnClickListener {
            val nuevoEstado = !buzzerSilenciado
            dbRef.child("silenciar_buzzer").setValue(nuevoEstado)
                .addOnSuccessListener {
                    Toast.makeText(this, "silenciar_buzzer = $nuevoEstado", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error al guardar: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }
    }

    // Convierte Boolean, String ("true"/"false") o Number (1/0) sin fallar
    private fun leerBooleano(valor: Any?, defecto: Boolean): Boolean {
        return when (valor) {
            is Boolean -> valor
            is String -> valor.equals("true", ignoreCase = true) || valor == "1"
            is Number -> valor.toInt() != 0
            else -> defecto
        }
    }
}