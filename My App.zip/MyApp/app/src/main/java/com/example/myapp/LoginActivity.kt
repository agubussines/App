package com.example.myapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class LoginActivity : AppCompatActivity() {

    private val dbUrl = "https://aquaalertiot-default-rtdb.firebaseio.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsuario = findViewById<EditText>(R.id.etUsuario)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnIngresar = findViewById<Button>(R.id.btnIngresar)

        val usersRef = FirebaseDatabase.getInstance(dbUrl).getReference("usuarios")

        // Crea un usuario por defecto en Firebase si aún no existe (admin / 1234)
        usersRef.child("admin").get().addOnSuccessListener { snap ->
            if (!snap.exists()) {
                usersRef.child("admin").setValue("1234")
            }
        }

        btnIngresar.setOnClickListener {
            val usuario = etUsuario.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa usuario y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Verifica el usuario en el nodo "usuarios" de Firebase
            usersRef.child(usuario).get().addOnSuccessListener { snapshot ->
                val passGuardada = snapshot.value?.toString()
                if (snapshot.exists() && passGuardada == password) {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish() // Evita volver al login al presionar Atrás
                } else {
                    Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
            }.addOnFailureListener { e ->
                Toast.makeText(this, "Error de conexión: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}